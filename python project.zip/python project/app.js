const seedPlaces = [
  { id: 1, name: "Elm & Ivy Café", category: "Cafe", area: "Capitol Hill", address: "1421 10th Ave", rating: 4.9, description: "Sunlit corner café with house-roasted coffee and fresh pastries.", image: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=900&q=85", saved: true },
  { id: 2, name: "The Lantern", category: "Restaurant", area: "Pike Place", address: "86 Pike Street", rating: 4.8, description: "Modern Pacific Northwest cooking in a cozy neighborhood dining room.", image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=900&q=85", saved: false },
  { id: 3, name: "Calder Gardens", category: "Park", area: "South Lake Union", address: "410 Valley Street", rating: 4.7, description: "A quiet green escape with sculptures, ponds and winding trails.", image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=900&q=85", saved: false },
  { id: 4, name: "Fable & Form", category: "Culture", area: "Fremont", address: "3520 Fremont Ave", rating: 4.6, description: "Independent bookstore, gallery and a weekly calendar of intimate talks.", image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=900&q=85", saved: false },
  { id: 5, name: "Market Row", category: "Shopping", area: "Ballard", address: "5400 22nd Ave", rating: 4.5, description: "Local makers, vintage finds and thoughtful goods under one roof.", image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=900&q=85", saved: true },
  { id: 6, name: "Juniper Kitchen", category: "Restaurant", area: "Queen Anne", address: "221 W Mercer St", rating: 4.8, description: "Seasonal plates, handmade pasta and a relaxed all-day atmosphere.", image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=900&q=85", saved: false },
  { id: 7, name: "Harbor Glassworks", category: "Culture", area: "Georgetown", address: "5700 4th Ave S", rating: 4.7, description: "Live glassmaking, rotating exhibitions and hands-on weekend workshops.", image: "https://images.unsplash.com/photo-1564399579883-451a5d44ec08?auto=format&fit=crop&w=900&q=85", saved: false },
  { id: 8, name: "Cedar Table", category: "Cafe", area: "Wallingford", address: "4320 Stone Way", rating: 4.6, description: "All-day brunch, botanical teas and an inviting shaded patio.", image: "https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=900&q=85", saved: false },
  { id: 9, name: "Northline Provisions", category: "Shopping", area: "Green Lake", address: "7100 Latona Ave", rating: 4.4, description: "Neighborhood pantry stocked with regional foods and useful everyday goods.", image: "https://images.unsplash.com/photo-1604719312566-8912e9227c6a?auto=format&fit=crop&w=900&q=85", saved: false }
];

const categoryIcons = { Cafe: "☕", Restaurant: "🍽", Park: "🌿", Culture: "🎨", Shopping: "🛍" };
let places = loadPlaces();
let activeCategory = "All";
let activeView = "discover";
let sortMode = "recommended";

const grid = document.getElementById("placeGrid");
const searchInput = document.getElementById("searchInput");
const emptyState = document.getElementById("emptyState");
const modalBackdrop = document.getElementById("modalBackdrop");
const placeForm = document.getElementById("placeForm");

function loadPlaces() {
  try {
    const stored = localStorage.getItem("nearnest-places");
    return stored ? JSON.parse(stored) : seedPlaces;
  } catch {
    return seedPlaces;
  }
}

function savePlaces() {
  localStorage.setItem("nearnest-places", JSON.stringify(places));
}

function cardTemplate(place) {
  return `
    <article class="place-card" data-id="${place.id}">
      <div class="card-image">
        <img src="${place.image || "https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=900&q=85"}" alt="${escapeHtml(place.name)}">
        <button class="save-button ${place.saved ? "saved" : ""}" data-save="${place.id}" aria-label="${place.saved ? "Remove from saved" : "Save place"}">
          <svg viewBox="0 0 24 24"><path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1z"/></svg>
        </button>
        <span class="category-badge">${categoryIcons[place.category] || "📍"} ${place.category}</span>
      </div>
      <div class="card-body">
        <div class="card-title-row">
          <h3 title="${escapeHtml(place.name)}">${escapeHtml(place.name)}</h3>
          <div class="rating"><span>★</span>${Number(place.rating).toFixed(1)}</div>
        </div>
        <p class="card-meta"><strong>${escapeHtml(place.area)}</strong> · ${escapeHtml(place.address)}</p>
        <p class="card-description">${escapeHtml(place.description)}</p>
      </div>
    </article>`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[char]));
}

function render() {
  const query = searchInput.value.trim().toLowerCase();
  let filtered = places.filter(place => {
    const matchesCategory = activeCategory === "All" || place.category === activeCategory;
    const searchable = `${place.name} ${place.category} ${place.area} ${place.address} ${place.description}`.toLowerCase();
    const matchesSearch = !query || searchable.includes(query);
    const matchesView = activeView !== "saved" || place.saved;
    return matchesCategory && matchesSearch && matchesView;
  });

  if (sortMode === "rating") filtered = [...filtered].sort((a, b) => b.rating - a.rating);
  if (sortMode === "name") filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));

  grid.innerHTML = filtered.map(cardTemplate).join("");
  grid.hidden = filtered.length === 0;
  emptyState.hidden = filtered.length !== 0;
  document.getElementById("allCount").textContent = places.length;
  document.getElementById("savedCount").textContent = places.filter(place => place.saved).length;
  document.getElementById("resultCount").textContent = `${filtered.length} ${filtered.length === 1 ? "place" : "places"} found`;

  document.querySelectorAll("[data-save]").forEach(button => {
    button.addEventListener("click", event => {
      event.stopPropagation();
      const place = places.find(item => item.id === Number(button.dataset.save));
      place.saved = !place.saved;
      savePlaces();
      render();
      showToast(place.saved ? "Saved to your places" : "Removed from saved places");
    });
  });
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2200);
}

function openModal() {
  modalBackdrop.hidden = false;
  document.body.style.overflow = "hidden";
  placeForm.elements.name.focus();
}

function closeModal() {
  modalBackdrop.hidden = true;
  document.body.style.overflow = "";
  placeForm.reset();
  document.getElementById("formError").textContent = "";
}

document.getElementById("categories").addEventListener("click", event => {
  const chip = event.target.closest(".category-chip");
  if (!chip) return;
  activeCategory = chip.dataset.category;
  document.querySelectorAll(".category-chip").forEach(item => item.classList.toggle("active", item === chip));
  render();
});

document.querySelectorAll(".nav-item[data-view]").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item[data-view]").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    activeView = button.dataset.view;
    document.getElementById("pageTitle").innerHTML = activeView === "saved"
      ? "Your saved <span>places</span>"
      : activeView === "recent"
        ? "Recently <span>explored</span>"
        : 'Find your next favorite <span>place</span>';
    document.getElementById("pageSubtitle").textContent = activeView === "saved"
      ? "All the local gems you have tucked away for later."
      : "Curated spots, trusted by locals. No endless scrolling required.";
    document.getElementById("sectionTitle").textContent = activeView === "saved" ? "Saved places" : activeView === "recent" ? "Recent discoveries" : "Popular near you";
    document.querySelector(".sidebar").classList.remove("open");
    render();
  });
});

searchInput.addEventListener("input", render);
document.addEventListener("keydown", event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    searchInput.focus();
  }
  if (event.key === "Escape") closeModal();
});

document.getElementById("sortButton").addEventListener("click", () => {
  const modes = ["recommended", "rating", "name"];
  sortMode = modes[(modes.indexOf(sortMode) + 1) % modes.length];
  document.querySelector("#sortButton span").textContent =
    sortMode === "rating" ? "Highest rated" : sortMode === "name" ? "Name A–Z" : "Recommended";
  render();
});

document.getElementById("addPlaceButton").addEventListener("click", openModal);
document.getElementById("addPlaceNav").addEventListener("click", openModal);
document.getElementById("closeModal").addEventListener("click", closeModal);
document.getElementById("cancelModal").addEventListener("click", closeModal);
modalBackdrop.addEventListener("click", event => { if (event.target === modalBackdrop) closeModal(); });

placeForm.addEventListener("submit", event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(placeForm).entries());
  const rating = Number(data.rating);

  if (!data.name.trim() || !data.category || !data.area.trim() || !data.address.trim() || !data.description.trim()) {
    document.getElementById("formError").textContent = "Please complete every field.";
    return;
  }
  if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
    document.getElementById("formError").textContent = "Rating must be between 1 and 5.";
    return;
  }

  places.unshift({
    id: Date.now(),
    name: data.name.trim(),
    category: data.category,
    area: data.area.trim(),
    address: data.address.trim(),
    rating,
    description: data.description.trim(),
    saved: false,
    image: ""
  });
  savePlaces();
  closeModal();
  activeCategory = "All";
  activeView = "discover";
  document.querySelectorAll(".category-chip").forEach((chip, index) => chip.classList.toggle("active", index === 0));
  document.querySelectorAll(".nav-item[data-view]").forEach((item, index) => item.classList.toggle("active", index === 0));
  document.getElementById("pageTitle").innerHTML = 'Find your next favorite <span>place</span>';
  document.getElementById("sectionTitle").textContent = "Popular near you";
  render();
  showToast("Place added successfully");
});

document.getElementById("mobileMenu").addEventListener("click", () => {
  document.querySelector(".sidebar").classList.toggle("open");
});

document.getElementById("locationButton").addEventListener("click", () => {
  showToast("Using your current location");
});

document.getElementById("exportButton").addEventListener("click", () => {
  const columns = ["name", "category", "area", "address", "rating", "description"];
  const csv = [
    columns.join(","),
    ...places.map(place => columns.map(column => `"${String(place[column] ?? "").replace(/"/g, '""')}"`).join(","))
  ].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "nearnest-places.csv";
  link.click();
  URL.revokeObjectURL(url);
  showToast("Directory exported as CSV");
});

render();
